using Microsoft.Maui.Controls;
using Microsoft.Maui.Controls.Maps;
using System;
using System.Timers;

namespace PickAndDrop
{
    public partial class RealTimeTrackingPage : ContentPage
    {
        private Timer _timer;

        public RealTimeTrackingPage()
        {
            InitializeComponent();
            InitializeMap();
            StartTracking();
        }

        private void InitializeMap()
        {
            try
            {
                TrackingMap.IsShowingUser = true;
                TrackingMap.MoveToRegion(MapSpan.FromCenterAndRadius(new Location(37.7749, -122.4194), Distance.FromMiles(1)));
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private void StartTracking()
        {
            try
            {
                _timer = new Timer(5000); // Update every 5 seconds
                _timer.Elapsed += OnTimedEvent;
                _timer.AutoReset = true;
                _timer.Enabled = true;
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            try
            {
                // Fetch the driver's current location from the server (pseudo-code)
                // var driverLocation = await TrackingService.GetDriverLocationAsync();

                // For demonstration, we'll use a static location
                var driverLocation = new Location(37.7749, -122.4194);

                Device.BeginInvokeOnMainThread(() =>
                {
                    TrackingMap.Pins.Clear();
                    var pin = new Pin
                    {
                        Label = "Driver",
                        Location = driverLocation
                    };
                    TrackingMap.Pins.Add(pin);
                    TrackingMap.MoveToRegion(MapSpan.FromCenterAndRadius(driverLocation, Distance.FromMiles(1)));
                });
            }
            catch (Exception ex)
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await DisplayAlert("Error", ex.Message, "OK");
                });
            }
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            _timer?.Stop();
            _timer?.Dispose();
        }
    }
}
