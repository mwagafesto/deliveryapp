using Microsoft.Maui.Controls;
using PickAndDrop.Models;
using System;
using System.Collections.ObjectModel;

namespace PickAndDrop
{
    public partial class FoodDeliveryPage : ContentPage
    {
        private ObservableCollection<FoodOrder> Hotels { get; set; }
        private ObservableCollection<FoodOrder> MenuItems { get; set; }

        public FoodDeliveryPage()
        {
            InitializeComponent();
            LoadHotels();
        }

        private void LoadHotels()
        {
            try
            {
                Hotels = new ObservableCollection<FoodOrder>
                {
                    new FoodOrder { HotelName = "Hotel A" },
                    new FoodOrder { HotelName = "Hotel B" },
                    new FoodOrder { HotelName = "Hotel C" }
                };

                HotelsCollectionView.ItemsSource = Hotels;
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private void OnHotelSelected(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                var selectedHotel = e.CurrentSelection[0] as FoodOrder;
                LoadMenuItems(selectedHotel.HotelName);
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private void LoadMenuItems(string hotelName)
        {
            try
            {
                MenuItems = new ObservableCollection<FoodOrder>
                {
                    new FoodOrder { MenuItem = "Pizza" },
                    new FoodOrder { MenuItem = "Burger" },
                    new FoodOrder { MenuItem = "Pasta" }
                };

                MenuItemsCollectionView.ItemsSource = MenuItems;
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void OnMenuItemSelected(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                var selectedMenuItem = e.CurrentSelection[0] as FoodOrder;
                await DisplayAlert("Selected Item", $"You selected {selectedMenuItem.MenuItem}", "OK");
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void OnOrderNowClicked(object sender, EventArgs e)
        {
            try
            {
                // For demonstration, we'll just display an alert
                await DisplayAlert("Success", "Your food order has been placed!", "OK");
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }
    }
}
