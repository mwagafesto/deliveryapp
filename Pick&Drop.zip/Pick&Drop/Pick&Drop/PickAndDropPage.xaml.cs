using Microsoft.Maui.Controls;

namespace PickAndDrop
{
    public partial class PickAndDropPage : ContentPage
    {
        public PickAndDropPage()
        {
            InitializeComponent();
        }

        private async void OnBookRideClicked(object sender, EventArgs e)
        {
            try
            {
                await Navigation.PushAsync(new RideBookingPage());
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void OnRequestDeliveryClicked(object sender, EventArgs e)
        {
            try
            {
                await Navigation.PushAsync(new DeliveryServicePage());
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void OnOrderFoodClicked(object sender, EventArgs e)
        {
            try
            {
                await Navigation.PushAsync(new FoodDeliveryPage());
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void OnTrackClicked(object sender, EventArgs e)
        {
            try
            {
                await Navigation.PushAsync(new RealTimeTrackingPage());
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void OnRateDriverClicked(object sender, EventArgs e)
        {
            try
            {
                await Navigation.PushAsync(new UserDriverRatingsPage());
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void OnSettingsClicked(object sender, EventArgs e)
        {
            try
            {
                await Navigation.PushAsync(new SettingsPage());
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }
    }
}
