using Microsoft.Maui.Controls;
using PickAndDrop.Models;
using System;
using System.Collections.ObjectModel;

namespace PickAndDrop
{
    public partial class NotificationsPage : ContentPage
    {
        private ObservableCollection<Notification> Notifications { get; set; }

        public NotificationsPage()
        {
            InitializeComponent();
            LoadNotifications();
        }

        private void LoadNotifications()
        {
            try
            {
                Notifications = new ObservableCollection<Notification>
                {
                    new Notification { Title = "Ride Confirmed", Message = "Your ride has been confirmed.", Date = DateTime.Now.AddMinutes(-30) },
                    new Notification { Title = "Delivery Dispatched", Message = "Your delivery has been dispatched.", Date = DateTime.Now.AddHours(-1) },
                    new Notification { Title = "Food Order Placed", Message = "Your food order has been placed.", Date = DateTime.Now.AddHours(-2) }
                };

                NotificationsCollectionView.ItemsSource = Notifications;
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }
    }
}
