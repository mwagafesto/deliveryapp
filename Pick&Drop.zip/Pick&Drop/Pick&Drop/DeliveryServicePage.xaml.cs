using Microsoft.Maui.Controls;
using PickAndDrop.Models;
using System;

namespace PickAndDrop
{
    public partial class DeliveryServicePage : ContentPage
    {
        public DeliveryServicePage()
        {
            InitializeComponent();
        }

        private async void OnRequestDeliveryClicked(object sender, EventArgs e)
        {
            try
            {
                var deliveryRequest = new DeliveryRequest
                {
                    PickupAddress = PickupAddressEntry.Text,
                    DeliveryAddress = DeliveryAddressEntry.Text,
                    PackageDetails = PackageDetailsEntry.Text
                };

                // Send deliveryRequest to the server (pseudo-code)
                // var response = await DeliveryService.RequestDeliveryAsync(deliveryRequest);

                // For demonstration, we'll just display an alert
                await DisplayAlert("Success", "Your delivery request has been submitted!", "OK");
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }
    }
}
