using Microsoft.Maui.Controls;
using PickAndDrop.Models;
using System;

namespace PickAndDrop
{
    public partial class InAppPaymentPage : ContentPage
    {
        public InAppPaymentPage()
        {
            InitializeComponent();
        }

        private async void OnPayNowClicked(object sender, EventArgs e)
        {
            try
            {
                var paymentDetails = new PaymentDetails
                {
                    CardNumber = CardNumberEntry.Text,
                    ExpiryDate = ExpiryDateEntry.Text,
                    CVV = CVVEntry.Text
                };

                // Process payment (pseudo-code)
                // var response = await PaymentService.ProcessPaymentAsync(paymentDetails);

                // For demonstration, we'll just display an alert
                await DisplayAlert("Success", "Your payment has been processed!", "OK");
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }
    }
}
