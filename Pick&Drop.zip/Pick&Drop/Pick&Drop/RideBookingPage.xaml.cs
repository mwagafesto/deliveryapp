using Microsoft.Maui.Controls;
using PickAndDrop.Models;
using System;

namespace PickAndDrop
{
    public partial class RideBookingPage : ContentPage
    {
        public RideBookingPage()
        {
            InitializeComponent();
        }

        private async void OnBookNowClicked(object sender, EventArgs e)
        {
            try
            {
                var bookingRequest = new BookingRequest
                {
                    PickupLocation = PickupLocationEntry.Text,
                    DropOffLocation = DropOffLocationEntry.Text,
                    VehicleType = VehicleTypePicker.SelectedItem?.ToString()
                };

                // Send bookingRequest to the server (pseudo-code)
                // var response = await BookingService.BookRideAsync(bookingRequest);

                // For demonstration, we'll just display an alert
                await DisplayAlert("Success", "Your ride has been booked!", "OK");
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }
    }
}
