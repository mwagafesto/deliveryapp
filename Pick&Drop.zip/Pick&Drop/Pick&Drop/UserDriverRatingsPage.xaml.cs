using Microsoft.Maui.Controls;
using PickAndDrop.Models;
using System;
using System.Collections.ObjectModel;

namespace PickAndDrop
{
    public partial class UserDriverRatingsPage : ContentPage
    {
        private ObservableCollection<Rating> Rides { get; set; }
        private Rating SelectedRide { get; set; }

        public UserDriverRatingsPage()
        {
            InitializeComponent();
            LoadRides();
        }

        private void LoadRides()
        {
            try
            {
                Rides = new ObservableCollection<Rating>
                {
                    new Rating { DriverName = "John Doe", Date = DateTime.Now.AddDays(-1) },
                    new Rating { DriverName = "Jane Smith", Date = DateTime.Now.AddDays(-2) },
                    new Rating { DriverName = "Mike Johnson", Date = DateTime.Now.AddDays(-3) }
                };

                RidesCollectionView.ItemsSource = Rides;
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private void OnRideSelected(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                SelectedRide = e.CurrentSelection[0] as Rating;
                RatingStack.IsVisible = true;
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void OnSubmitRatingClicked(object sender, EventArgs e)
        {
            try
            {
                if (SelectedRide != null)
                {
                    var rating = new Rating
                    {
                        DriverName = SelectedRide.DriverName,
                        Score = RatingSlider.Value,
                        Comments = CommentsEntry.Text
                    };

                    // Submit rating to the server (pseudo-code)
                    // var response = await RatingService.SubmitRatingAsync(rating);

                    // For demonstration, we'll just display an alert
                    await DisplayAlert("Success", "Your rating has been submitted!", "OK");
                }
                else
                {
                    await DisplayAlert("Error", "Please select a ride to rate.", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }
    }
}
