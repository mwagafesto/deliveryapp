namespace PickAndDrop.Models
{
    public class DeliveryRequest
    {
        public string PickupAddress { get; set; }
        public string DeliveryAddress { get; set; }
        public string PackageDetails { get; set; }
    }
}
