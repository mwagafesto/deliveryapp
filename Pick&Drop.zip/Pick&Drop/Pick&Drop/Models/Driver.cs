namespace PickAndDrop.Models
{
    public class Driver
    {
        public string Name { get; set; }
        public string Vehicle { get; set; }
        public double Rating { get; set; }
    }
}
