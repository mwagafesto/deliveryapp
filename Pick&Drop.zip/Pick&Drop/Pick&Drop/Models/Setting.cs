namespace PickAndDrop.Models
{
    public class Setting
    {
        public string Language { get; set; }
        public string Currency { get; set; }
    }
}
