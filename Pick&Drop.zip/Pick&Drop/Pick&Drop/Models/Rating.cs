namespace PickAndDrop.Models
{
    public class Rating
    {
        public string DriverName { get; set; }
        public double Score { get; set; }
        public string Comments { get; set; }
    }
}
