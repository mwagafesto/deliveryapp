namespace PickAndDrop.Models
{
    public class FoodOrder
    {
        public string HotelName { get; set; }
        public string MenuItem { get; set; }
        public int Quantity { get; set; }
    }
}
