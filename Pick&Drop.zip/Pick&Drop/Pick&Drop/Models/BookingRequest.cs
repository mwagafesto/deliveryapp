namespace PickAndDrop.Models
{
    public class BookingRequest
    {
        public string PickupLocation { get; set; }
        public string DropOffLocation { get; set; }
        public string VehicleType { get; set; }
    }
}
