namespace PickAndDrop.Models
{
    public class Notification
    {
        public string Title { get; set; }
        public string Message { get; set; }
        public DateTime Date { get; set; }
    }
}
