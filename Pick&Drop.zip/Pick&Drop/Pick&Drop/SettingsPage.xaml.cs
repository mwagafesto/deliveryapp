using Microsoft.Maui.Controls;
using Microsoft.Maui.Storage;
using PickAndDrop.Models;
using System;

namespace PickAndDrop
{
    public partial class SettingsPage : ContentPage
    {
        public SettingsPage()
        {
            InitializeComponent();
            LoadSettings();
        }

        private void LoadSettings()
        {
            try
            {
                var language = Preferences.Get("Language", "English");
                var currency = Preferences.Get("Currency", "USD");

                LanguagePicker.SelectedItem = language;
                CurrencyPicker.SelectedItem = currency;
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void OnSaveClicked(object sender, EventArgs e)
        {
            try
            {
                var selectedLanguage = LanguagePicker.SelectedItem?.ToString();
                var selectedCurrency = CurrencyPicker.SelectedItem?.ToString();

                if (!string.IsNullOrEmpty(selectedLanguage) && !string.IsNullOrEmpty(selectedCurrency))
                {
                    Preferences.Set("Language", selectedLanguage);
                    Preferences.Set("Currency", selectedCurrency);

                    await DisplayAlert("Success", "Settings have been saved!", "OK");
                }
                else
                {
                    await DisplayAlert("Error", "Please select both language and currency.", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }
    }
}
