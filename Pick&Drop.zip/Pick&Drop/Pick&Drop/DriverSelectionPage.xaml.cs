using Microsoft.Maui.Controls;
using PickAndDrop.Models;
using System;
using System.Collections.ObjectModel;

namespace PickAndDrop
{
    public partial class DriverSelectionPage : ContentPage
    {
        private ObservableCollection<Driver> Drivers { get; set; }
        private Driver SelectedDriver { get; set; }

        public DriverSelectionPage()
        {
            InitializeComponent();
            LoadDrivers();
        }

        private void LoadDrivers()
        {
            try
            {
                Drivers = new ObservableCollection<Driver>
                {
                    new Driver { Name = "John Doe", Vehicle = "Car", Rating = 4.5 },
                    new Driver { Name = "Jane Smith", Vehicle = "Bike", Rating = 4.7 },
                    new Driver { Name = "Mike Johnson", Vehicle = "Van", Rating = 4.3 }
                };

                DriversCollectionView.ItemsSource = Drivers;
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private void OnDriverSelected(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                SelectedDriver = e.CurrentSelection[0] as Driver;
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void OnSelectDriverClicked(object sender, EventArgs e)
        {
            try
            {
                if (SelectedDriver != null)
                {
                    // For demonstration, we'll just display an alert
                    await DisplayAlert("Driver Selected", $"You selected {SelectedDriver.Name}", "OK");
                }
                else
                {
                    await DisplayAlert("Error", "Please select a driver.", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }
    }
}
